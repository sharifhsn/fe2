use fe680::assn3::*;

fn main() {
    prob1::a();
    prob2::a();
    prob3::a();
    prob4::a();
}
