use plotters::prelude::*;
use statrs::distribution::{ContinuousCDF, Normal};
const BP: f64 = 0.0001;

pub struct SpreadDynamics {
    pub s1: f64,
    pub s2: f64,
    pub R: f64,
    pub T: Vec<f64>,
    pub rho: f64,
    pub h1: f64,
    pub h2: f64,
    pub normal: Normal,
}

pub fn h(s: f64, R: f64) -> f64 {
    s * (1.0 - R)
}

impl SpreadDynamics {
    pub fn new(s1: f64, s2: f64, R: f64, T: Vec<f64>, rho: f64) -> Self {
        SpreadDynamics {
            s1,
            s2,
            R,
            T,
            rho,
            h1: h(s1, R),
            h2: h(s2, R),
            normal: Normal::standard(),
        }
    }

    pub fn C1(&self, t: f64) -> f64 {
        self.normal.inverse_cdf(self.h1 * t)
    }

    pub fn C2(&self, t: f64) -> f64 {
        self.normal.inverse_cdf(self.h2 * t)
    }

    pub fn Q2hat(&self, t: f64, T: f64) -> f64 {
        1.0 - ((self
            .normal
            .cdf((self.C2(T) - self.rho * self.C1(t)) / (1.0 - self.rho.powi(2)).sqrt())
            - self
                .normal
                .cdf((self.C2(t) - self.rho * self.C1(t)) / (1.0 - self.rho.powi(2)).sqrt())) / (1.0
            - self
                .normal
                .cdf((self.C2(t) - self.rho * self.C1(t)) / (1.0 - self.rho.powi(2)).sqrt())))
    }

    pub fn forward_spread(&self) -> Vec<f64> {
        let T = self.T[self.T.len() - 1];
        self.T
            .iter()
            .take(self.T.len() - 1)
            .map(|t| {
                (1.0 - self.R) * (1.0 - self.Q2hat(*t, T)) / (T - t) / BP
            })
            .collect()
    }
}

pub fn a() {
    let s1 = 60.0 * BP;
    let s2 = 100.0 * BP;
    let R = 0.3;
    let T: Vec<f64> = (5..=500).map(|i| i as f64 / 100.0).collect::<Vec<f64>>();
    let rhos: Vec<f64> = vec![-0.5, -0.3, -0.1, 0.0, 0.1, 0.3, 0.5];
    let spreads = rhos
        .iter()
        .map(|rho| {
            let sd = SpreadDynamics::new(s1, s2, R, T.clone(), *rho);
            sd.forward_spread()
        })
        .collect::<Vec<Vec<f64>>>();
    let root_area = BitMapBackend::new("spread_dynamics.png", (1024, 768)).into_drawing_area();
    root_area.fill(&WHITE).unwrap();

    let mut chart = ChartBuilder::on(&root_area)
        .caption("Spread Dynamics for Credit 2 Given Correlation with Defaulted Credit 1", ("sans-serif", 30))
        .margin(10)
        .x_label_area_size(40)
        .y_label_area_size(40)
        .build_cartesian_2d(
            0.0..T[T.len() - 1],
            spreads
                .iter()
                .flatten()
                .cloned()
                .fold(f64::INFINITY, f64::min)
                ..spreads
                    .iter()
                    .flatten()
                    .cloned()
                    .fold(f64::NEG_INFINITY, f64::max),
        )
        .unwrap();

    chart
        .configure_mesh()
        .x_desc("T (yrs)")
        .y_desc("Spread (bps)")
        .draw()
        .unwrap();

    for (i, spread) in spreads.iter().enumerate() {
        chart
            .draw_series(LineSeries::new(
                T.iter().cloned().zip(spread.iter().cloned()),
                &Palette99::pick(i),
            ))
            .unwrap()
            .label(format!("ρ = {}", rhos[i]))
            .legend(move |(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &Palette99::pick(i)));
    }

    chart
        .configure_series_labels()
        .border_style(&BLACK)
        .draw()
        .unwrap();
}
