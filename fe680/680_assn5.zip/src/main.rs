use fe680::assn5::*;

fn main() {
    prob1::a();
}
