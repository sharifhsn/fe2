use fe680::assn5::*;

fn main() {
    prob2::a();
}
