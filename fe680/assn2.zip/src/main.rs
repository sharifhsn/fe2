use fe680::assn2::*;

fn main() {
    println!("{}", prob1::a().unwrap());
    println!("{}", prob2::a().unwrap());
    println!("{}", prob3::a().unwrap());
    println!("{}", prob4::a().unwrap());
    println!("{}", prob5::a().unwrap());
}
