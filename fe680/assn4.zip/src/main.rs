use fe680::assn4::*;

fn main() {
    prob1::a();
    prob2::a();
    prob3::a();
}
