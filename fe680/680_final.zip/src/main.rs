use fe680::fin::*;

fn main() {
    prob1::a();
    prob1::b();
    // prob2::a();
    // prob2::b();
    // prob3::a();
    // prob4::a();
    // prob4::b();
    // prob5::a();
    // prob6::a();
    // prob6::b();
    // prob6::c();
}
