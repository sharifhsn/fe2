use fe621::assn5::*;

fn main() {
    prob1::a();
    prob1::b();
    prob1::c();
    prob1::d();
}
