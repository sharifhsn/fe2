use fe621::assn4::*;

fn main() {
    prob1::a();
}
