use fe621::assn2::*;

fn main() {
    //a();
    prob1::a();
    prob1::b();
    prob1::d();
    prob2::a();
}
