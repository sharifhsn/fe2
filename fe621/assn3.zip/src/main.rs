use fe621::assn3::*;

fn main() {
    prob1::a().unwrap();
}
