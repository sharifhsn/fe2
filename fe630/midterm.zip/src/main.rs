use fe630::midterm::*;

fn main() {
    a().unwrap();
}
